<?php include 'conexion.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Venta de Propiedades</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
   
    <div class="navbar">
        <div class="navbar-logo">BIENES<span>RAICES</span></div>
        <ul class="navbar-links">
            <li><a href="#">Nosotros</a></li>
            <li><a href="#">Anuncios</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Contacto</a></li>
        </ul>
    </div>

    <div class="container">
        <h1>Registrar Venta de Propiedad</h1>
        <form method="POST" action="index.php">
            <label for="propiedad_id">Selecciona la Propiedad Vendida:</label>
            <select name="propiedad_id" id="propiedad_id" required>
                <?php while ($row = $result->fetch_assoc()) : ?>
                    <option value="<?php echo $row['id']; ?>">
                        <?php echo $row['titulo'] . " - $" . number_format($row['precio'], 2); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label for="comprador">Nombre del Comprador:</label>
            <input type="text" name="comprador" id="comprador" required>

            <button type="submit" name="vender">Registrar Venta</button>
        </form>
    </div>
</body>
</html>
