<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bienesraices";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['vender'])) {
    $propiedad_id = $_POST['propiedad_id'];
    $comprador = $_POST['comprador'];

    $stmt = $conn->prepare("INSERT INTO propiedadesVendidas (propiedad_id, comprador) VALUES (?, ?)");
    $stmt->bind_param("is", $propiedad_id, $comprador);

    if ($stmt->execute()) {
        echo "¡Propiedad vendida registrada exitosamente!";
    } else {
        echo "Error al registrar la venta: " . $conn->error;
    }
    $stmt->close();
}

$sql = "SELECT * FROM propiedades";
$result = $conn->query($sql);
?>
